#!/bin/bash
nohup python3 learn_ROI_neurons.py &
nohup python3 learn_ROI_dropout.py &
